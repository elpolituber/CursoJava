package com.clearminds.conceptos;

public class Calculadora {

	public int sumar(int a, int b){
		return a+b;
	}
	public double restar(double a, double b){
		return a-b;
	}
	public double multiplicar(double a, double b){
		return a*b;
	}
	public double dividir(double a, double b){
		return a/b;
	}
	
	public void imprimir(){
		System.out.println("Impreso");
	}
	
	
}
