package com.clearminds.test;
import com.clearminds.entidades.Auto;

public class TestAuto {

	public static void main(String[] args) {
		Auto auto=new Auto();
		auto.setMarca("Toyota");
		auto.setPrecio(5000.00);
		auto.setAnio(1998);	
		System.out.println("marca: "+auto.getMarca());
		System.out.println("precio: "+auto.getPrecio());
		System.out.println("a�o: "+auto.getAnio());
		
		System.out.println("****************************");
		
		Auto auto2=new Auto();
		auto2.setMarca("Mustan");
		auto2.setPrecio(500000.00);
		auto2.setAnio(2006);	
		System.out.println("marca: "+auto2.getMarca());
		System.out.println("precio: "+auto2.getPrecio());
		System.out.println("a�o: "+auto2.getAnio());
		
		Auto auto3=new Auto("porche",1500000.00,2020);
		System.out.println("marca: "+auto3.getMarca());
		System.out.println("precio: "+auto3.getPrecio());
		System.out.println("a�o: "+auto3.getAnio());
		
	}

}
