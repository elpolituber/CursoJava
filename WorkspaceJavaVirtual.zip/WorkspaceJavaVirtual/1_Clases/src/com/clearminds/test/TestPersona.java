package com.clearminds.test;
import com.clearminds.entidades.Persona;

/*
 * */
public class TestPersona {

	public static void main(String[] args) {
		Persona p3=new Persona();
		Persona p4=new Persona("maria",23,145.3);
		
		Persona p1;//declaro la variable tipo persona
		p1=new Persona("juan");//Creo el objeto  Persona y lo referencio com p1
		
		System.out.println("nombre: "+p1.getNombre());
		System.out.println("edad:"+p1.getEdad());
		System.out.println("estatura"+p1.getEstatura());
		
	
		//p1.setNombre("juan");
		p1.setEdad(20);
		p1.setEstatura(1.75);
		
		System.out.println("nombre: "+p1.getNombre());
		System.out.println("edad:"+p1.getEdad());
		System.out.println("estatura"+p1.getEstatura());
		
		System.out.println("***************");
		Persona p2;
		
		p2=new Persona("Marco");
		
		System.out.println("nombre: "+p2.getNombre());
		//p2.setNombre("Marco");
		System.out.println("nombre: "+p2.getNombre());
		
	}

}
