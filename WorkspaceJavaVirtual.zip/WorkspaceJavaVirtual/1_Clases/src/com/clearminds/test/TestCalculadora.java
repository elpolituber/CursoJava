package com.clearminds.test;
import com.clearminds.conceptos.Calculadora;
import com.clearminds.entidades.*;

public class TestCalculadora {

	public static void main(String[] args) {

		Calculadora c=new Calculadora();
		int resultado=c.sumar(5, 8);
		System.out.println("El resultado es:"+ resultado);
		c.imprimir();
		double resultador=c.restar(5.01, 8.00);
		System.out.println("El resultado es:"+ resultador);
		
		double resultadom=c.multiplicar(5.1, 8.8);
		System.out.println("El resultado es:"+ resultadom);
		
		double resultadod=c.dividir(5.01, 8.00);
		System.out.println("El resultado es:"+ resultadod);
		
		Persona p;
		Usuario	u;
		
	}

}
