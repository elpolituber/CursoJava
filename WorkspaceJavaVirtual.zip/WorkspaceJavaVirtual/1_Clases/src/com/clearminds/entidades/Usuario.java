package com.clearminds.entidades;

public class Usuario {

}
