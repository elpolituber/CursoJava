package com.cmc.log;

public class TestAdmin {

	public static void main(String[] args) {
	
		Admin admin=new Admin();
		admin.agregar();
	}
}
