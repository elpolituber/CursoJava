package com.clearminds.cuentas;

public class Cuenta {
	
	private String id = "A";
	private String tipo ="A";
	private double saldo;
	
	public String getTipo() {
		return tipo;
	}
	
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	public double getSaldo() {
		return saldo;
	}
	
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	public String getId() {
		return id;
	}

	public Cuenta(String id) {
		
		this.id = id;
	}

	public Cuenta(String id, String tipo, double saldo) {
		this.id = id;
		this.tipo = tipo;
		this.saldo = saldo;
	}

	public void imprimir(){
		System.out.println("*****************");
		System.out.println("Cuenta");
		System.out.println("*****************");
		System.out.println("N�mero de cuenta: "+getId());
		System.out.println("Tipo: "+getTipo());
		System.out.println("Saldo: "+getSaldo());
		System.out.println("****************");
		
	}
	public void imprimirComMiEstilo(){
	
		System.out.println("\n"+"\n"+"************************"+"\n\n"+
		"CUENTA"+
		"\n\n"+"***********************"+"\n"+
		"N�mero de cuenta: "+getId()+"\n"+
		"Tipo: "+getTipo()+"\n"+
		"Saldo: "+getSaldo()+"\n"
		+"***********************"
		);
	}
	
}
