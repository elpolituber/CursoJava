package com.cmc.colecciones;

import java.util.ArrayList;

import com.cmc.entidades.Persona;

public class Ejemplo1 {
	public static void main(String[] args){
		Persona p=new Persona("juan",12);
		
		ArrayList<String> lista;
		
		lista=new ArrayList<String>();
		
		
	}
}
