package com.cmc.colecciones;

import java.util.ArrayList;

import com.cmc.entidades.Persona;

public class Ejemplo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String>lista=new ArrayList<>(); 
		ArrayList<Persona>listaPersona=new ArrayList<Persona>() ;
		
		lista.add("a");
		listaPersona.add(new Persona("A",12));
		
		lista.get(0);
		listaPersona.get(0);
	}

}
