package com.cmc.colecciones;

import java.util.ArrayList;

public class Ejemplo2 {

	public static void main(String[] args) {
		ArrayList<String>lista=new ArrayList<>();
		lista.add("a");//0
		lista.add("b");//1
		lista.add("c");//2
		
		String recu=lista.get(2);
		System.out.println(recu);
		
		int tama=lista.size();
		System.out.println("tama�o"+tama);
		String cadena;
		for (int i = 0; i < lista.size(); i++) {
			cadena=lista.get(i);
			System.out.println(cadena);
		}
		
		
	}
}
