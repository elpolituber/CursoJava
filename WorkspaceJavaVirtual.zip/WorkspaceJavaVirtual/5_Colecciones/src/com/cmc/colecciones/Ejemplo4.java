package com.cmc.colecciones;

import java.util.ArrayList;

import com.cmc.entidades.Persona;

public class Ejemplo4 {

	public static void main(String[] args) {
		ArrayList<Persona>personas=new ArrayList<Persona>();
		personas.add(new Persona("Marco",12));
		personas.add(new Persona("Maria",13));
		personas.add(new Persona("Moran",26));
		System.out.println(personas.size());
		Persona per;
		for (int i = 0; i < personas.size(); i++) {
			per=personas.get(i);
			System.out.println(per.getNombre()+"-"+per.getEdad());
		}
	}

}
