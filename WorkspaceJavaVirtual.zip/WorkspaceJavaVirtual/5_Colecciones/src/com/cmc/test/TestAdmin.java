package com.cmc.test;

import java.util.ArrayList;

import com.cmc.colecciones.AdminPersona;
import com.cmc.entidades.Persona;

public class TestAdmin {

	public static void main(String[] args) {
		AdminPersona admin=new AdminPersona();
		admin.agregar(new Persona("Malcom", 10));
		admin.agregar(new Persona("Recese", 12));
		admin.agregar(new Persona("lois", 32));
		
		admin.imprimir();	
		
		Persona res=admin.buscar("Recese");
		if(res==null){
			System.out.println("no se encontro");
		}else{
		System.out.println("encontro: "+res.getNombre());
		}
		ArrayList<Persona>ps=admin.buscarMayores(18);
		System.out.println(ps.size());
	}

}
