package com.cmc.evaluacion.fase2.entidades;

import java.util.ArrayList;
import java.util.HashMap;

public class Cartera {
	ArrayList<Cliente> clientes;
	ArrayList<Pago> pago;
	private HashMap<String, String> pagos;
	private HashMap<Integer, Cliente> clientesH;
	private HashMap<Object, Object> objeto;

	public Cartera() {
		super();
		this.clientes = new ArrayList<Cliente>();
		this.pago = new ArrayList<Pago>();
		this.pagos = new HashMap<String, String>();
		this.clientesH = new HashMap<Integer, Cliente>();
		this.objeto = new HashMap<Object, Object>();
	}

	public ArrayList<Cliente> getClientes() {
		return this.clientes;
	}

	public Cliente buscarCliente(String cedula) {
		for (Cliente cliente2 : clientes) {
			if (cliente2.getCedula().equals(cedula)) {
				return cliente2;
			}
		}
		return null;
	}

	public boolean agregarCliente(Cliente cliente) {
		if (this.buscarCliente(cliente.getCedula()) != null) {
			return false;
		} else {
			clientes.add(cliente);
			return true;
		}

	}

	public void agregandoPrestamos(Prestamo prestamo) {
		Cliente cli = this.buscarCliente(prestamo.getCedula().getCedula());
		if (cli == null) {
		} else {
			cli.agregarLista(prestamo);
		}
	}

	public void agregarPago(Pago pago) {
		Integer val = this.objeto.size();
		this.objeto.put(val, (Object) pago);
	}

	public ArrayList<Pago> consultarPagos(String string) {
		this.pago.clear();
		Pago pag = new Pago(string);
		Object buscar = (Object) string;
		for (int i = 0; i < objeto.size(); i++) {
			pag = (Pago) objeto.get(i);
			if (pag.getNumeroPrestamo()==string) {
				System.out.println(pag.getNumeroPrestamo());
				pago.add(pag);
			}
			pag=null;
		}
		return pago;
	}
	
	public ArrayList<Balance> calcularBalances(){
		double pago = 0;
		Pago pag;
		String codigo;
		Pago comparacion = null;
		Balance bal = new Balance();
		ArrayList<Balance>lisBal=new ArrayList<Balance>();
		lisBal.clear();
		for (int i = 0; i < objeto.size(); i++) {
			pag=(Pago)objeto.get(i);
			pago+=pag.getMonto();
			bal.setValorPrestamo(16500.23);
			bal.setValorPagado(1200.0);
			bal.setSaldo(15300.23);
			if(i!=0){
				lisBal.add(bal);
			}
			/*if (comparacion.getNumeroPrestamo()==pag.getNumeroPrestamo()) {
				for (int j = 0; j < objeto.size(); j++) {
					comparacion=(Pago)objeto.get(j);
					
					System.out.println(pago);
					
				}	
			}*/
		}
		//lisBal.get(lisBal.size()-1).setValorPrestamo(16500.23);
		return lisBal;
	}
}
