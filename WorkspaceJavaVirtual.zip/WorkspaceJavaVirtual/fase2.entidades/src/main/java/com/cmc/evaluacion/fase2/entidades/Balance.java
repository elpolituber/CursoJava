package com.cmc.evaluacion.fase2.entidades;

import java.util.ArrayList;

public class Balance {
private	int numeroCedula;
	private double valorPrestamo;
	private double valorPagado;
	private double saldo;
	public int getNumeroCedula() {
		return numeroCedula;
	}
	public void setNumeroCedula(int numeroCedula) {
		this.numeroCedula = numeroCedula;
	}
	public double getValorPrestamo() {
		return valorPrestamo;
	}
	public void setValorPrestamo(double valorPrestamo) {
		this.valorPrestamo = valorPrestamo;
	}
	public double getValorPagado() {
		return valorPagado;
	}
	public void setValorPagado(double valorPagado) {
		this.valorPagado = valorPagado;
	}
	public double getSaldo() {
		return saldo;
	}
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
}
