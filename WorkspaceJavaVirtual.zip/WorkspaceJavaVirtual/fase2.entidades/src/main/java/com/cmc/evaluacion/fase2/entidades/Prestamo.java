package com.cmc.evaluacion.fase2.entidades;

import java.util.Date;

public class Prestamo {
	private String numero;
	private Date fecha;
	private double monto;
	private String tipo;
	private Cliente cedula;
	
	public Prestamo(String numero, Cliente cedula) {
		super();
		this.numero = numero;
		this.cedula = cedula;
	}

	public String getNumero() {
		return numero;
	}

	public Date getFecha() {
		return fecha;
	}

	public double getMonto() {
		return monto;
	}

	public String getTipo() {
		return tipo;
	}

	public Cliente getCedula() {
		return cedula;
	}
	
	
	
}
