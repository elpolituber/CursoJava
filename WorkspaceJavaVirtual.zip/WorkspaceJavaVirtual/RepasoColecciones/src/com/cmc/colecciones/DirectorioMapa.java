package com.cmc.colecciones;

import java.util.HashMap;
import java.util.Iterator;

import com.cmc.entidades.Contacto;

public class DirectorioMapa extends Directorio {
	private HashMap<String, Contacto> contactos;

	public DirectorioMapa() {
		super();
		this.contactos = new HashMap<String, Contacto>();
	}

	public void agregarContacto(Contacto cont){
		if(!this.contactos.containsKey(cont.getCedula())){
			this.contactos.put(cont.getCedula(), cont);	
		}
	}

	public Contacto buscarContacto(String cedula) {
		if(this.contactos.containsKey(cedula)){
			return this.contactos.get(cedula);	
		}
		return null;
	}

	public Contacto eliminarContacto(String cedula) {
		if(this.contactos.containsKey(cedula)){
			Contacto con=this.contactos.get(cedula);
			contactos.remove(cedula);
			return con ;	
		}
		return null;
	}

	public void imprimir() {
			System.out.println(this.contactos);
		
	}
}
