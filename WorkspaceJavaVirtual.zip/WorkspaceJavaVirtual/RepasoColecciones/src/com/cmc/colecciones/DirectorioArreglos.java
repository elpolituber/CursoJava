package com.cmc.colecciones;

import com.cmc.entidades.Contacto;

public class DirectorioArreglos extends Directorio {
	private Contacto[] contactos;
	private int elementosAgregados;
	
	public DirectorioArreglos(){
		contactos=new Contacto[3];
	}
	
	
	public void agregarContacto(Contacto cont){
		if (elementosAgregados<contactos.length) {
			contactos[elementosAgregados]=cont;
			elementosAgregados=+1;
		}
	}
	 public Contacto buscarContacto(String cedula){
		 for (Contacto contacto : contactos) {
			if(contacto.getCedula().equals(cedula)){
				return contacto;
			}
		}
		 return null;
	 }
	 public Contacto eliminarContacto(String cedula){
		 for (Contacto contacto : contactos) {
				if(contacto.getCedula().equals(cedula)){
					return contacto;
				}
			}	 
		 return null;
	}
	 public void imprimir(){
		 for (Contacto contacto : contactos) {
			System.out.println(contacto);	
			}
	 }
}
