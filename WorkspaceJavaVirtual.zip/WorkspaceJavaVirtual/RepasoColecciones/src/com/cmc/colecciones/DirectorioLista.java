package com.cmc.colecciones;

import java.util.ArrayList;
import java.util.Iterator;

import com.cmc.entidades.Contacto;

public class DirectorioLista extends Directorio {
	private ArrayList<Contacto> contactos;

	public DirectorioLista() {
		super();
		this.contactos = new ArrayList<Contacto>();
	}

	public void agregarContacto(Contacto cont) {
		if (this.contactos == null) {
			for (int i = 0; i < this.contactos.size(); i++) {
				// if(!contactos.get(i).getCedula().equals(cont.getCedula())){
				this.contactos.add(cont);
				// }else{
				System.out.println("aqui no");
				// }
			}
		}else{
			this.contactos.add(cont);
		}
		;
	}

	public Contacto buscarContacto(String cedula) {
		for (Contacto contacto : this.contactos) {
			if (contacto.getCedula().equals(cedula)) {
				return contacto;
			}
		}
		return null;
	}

	public Contacto eliminarContacto(String cedula) {
		int index = 0;
		for (Contacto contacto : contactos) {
			if (contacto.getCedula().equals(cedula)) {
				Contacto res = contacto;
				contactos.remove(index);
				return res;
			}
			index++;
		}
		return null;
	}

	public void imprimir() {
		for (Contacto contacto : contactos) {
			System.out.println(contacto);
		}
	}
}
