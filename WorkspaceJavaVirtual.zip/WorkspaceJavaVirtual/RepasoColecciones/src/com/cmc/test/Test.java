package com.cmc.test;

import com.cmc.entidades.Contacto;
import com.cmc.entidades.Telefono;

public class Test {

	public static void main(String[] args) {
		Contacto con=new Contacto("172151", "franco", "zabala");
		con.agregarTelefono(new Telefono("movi","023146545"));
		System.out.println(con);
	}

}
