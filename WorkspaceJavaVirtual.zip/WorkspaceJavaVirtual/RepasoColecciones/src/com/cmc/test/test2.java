package com.cmc.test;

import com.cmc.colecciones.Directorio;
import com.cmc.entidades.Contacto;
import com.cmc.entidades.Telefono;

public class test2 {

	public static void main(String[] args) {
		Directorio directorio=new Directorio();
		Contacto cont=new Contacto("123", "f", "z");
		cont.agregarTelefono(new Telefono("movi", "123156465"));
		directorio.agregarContacto(cont);
		directorio.buscarContacto("123");
		directorio.eliminarContacto("123");
		directorio.imprimir();
	}

}
