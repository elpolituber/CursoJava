package com.cmc.test;

import com.cmc.colecciones.DirectorioLista;
import com.cmc.colecciones.DirectorioMapa;
import com.cmc.entidades.Contacto;
import com.cmc.entidades.Telefono;

public class TestMap {

	public static void main(String[] args) {
		DirectorioMapa directorio=new DirectorioMapa();
		Contacto cont=new Contacto("123", "f", "z");
		cont.agregarTelefono(new Telefono("movi", "123156465"));
		directorio.agregarContacto(cont);
		directorio.imprimir();
		Contacto busqueda=directorio.buscarContacto("123");
		System.out.println("Encontrado "+busqueda);
		Contacto res=directorio.eliminarContacto("123");
		System.out.println("Se elimino "+res);
		directorio.imprimir();
	}

}
