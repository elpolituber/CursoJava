package com.cmc.test;

import com.cmc.estaticos.DiasSemanas;
import static java.lang.Math.PI;
import static java.lang.Math.random;
import static java.lang.System.out;

public class TestDiasSemanas {

	public static void main(String[] args) {
		DiasSemanas ds=new DiasSemanas();
		int val=ds.MARTES;
		System.out.println(val);
		System.out.println(DiasSemanas.MIERCOLES);
		double d1=Math.PI;
		System.out.println(d1);
		double d2=random();
		out.println(d2);
	}
	

}
