package com.cmc.test;

import com.cmc.estaticos.Util;

public class TestValidar {

	public static void main(String[] args) {
		Util util=new Util();
		boolean res=util.validaRango(5);
		
		System.out.println(res);
		boolean res2=Util.validaPositivo(6);
		System.out.println(res2);
	}

}
