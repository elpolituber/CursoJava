package com.cmc.test;

import com.cmc.estaticos.Contador;

public class TestContador {
	public static void main(String[] args) {
		Contador contador=new Contador("objeto1");
		contador.incremetar();
		contador.imprimir();
		
		Contador contador2=new Contador("objeto2");
		contador2.incremetar();
		contador2.imprimir();
		
	}
}
