package com.cmc.estaticos;

public class Util {
	
	public boolean validaRango(int valor){
		if (valor>0 && valor<10) {
			return true; 
		}else{
			return false;
		}
	}
	public static boolean validaPositivo(int valor){
		if (valor>0 ) {
			return true; 
		}else{
			return false;
		}
	}
}
