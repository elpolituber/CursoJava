package com.cmc.estaticos;

public class DiasSemanas {
	private final int LUNES =1;
	public final int MARTES =2;
	public final static int MIERCOLES =3;
	
	private void modificar() {
		//33lunes=5;
		
	}
}
