package com.cms.flujo.test;

import com.cmc.flujo.Validador;

public class TestValidador {

	public static void main(String[] args) {
		
		Validador validador= new Validador();
		validador.validarEdad(20);
//		String msg=validador.validarEdadMsg(18);
	//	boolean res=validador.esMayorDeEdad(14);
	//	System.out.println(res);
	}

}
