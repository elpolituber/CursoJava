package com.cmc.test;

import java.util.HashMap;

import com.cmc.entidades.Cliente;

public class TestMapaClientes {

	public static void main(String[] args) {
		HashMap<String,Cliente>map=new HashMap<String,Cliente>();
		map.put("1231561", new Cliente("1231561","Reamiro"));
		map.put("1231560", new Cliente("1231560","Reamiro"));
		
		Cliente cli=map.get("1231561");
		System.out.println(cli);
	}

}
