package com.cmc.juego;

import com.cmc.util.Dado;

public class AdminJuego {
	public void jugar() {
		int valor= Dado.lanzar();
	}
}
