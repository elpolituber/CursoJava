package com.cmc.util;

public class TestDado {

	public static void main(String[] args) {
		
		for (int i = 0; i < 10; i++) {
			System.out.println(Dado.lanzar());	
		}
	}

}
