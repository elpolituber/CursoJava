package com.cmc.exepciones;

public class Ejecicio1 {

	public static void main(String[] args) {
		System.out.println("Inicio");	
		try{
			System.out.println("Abrir conexion a bd");
			String a=null;
			a.substring(1,3);
			System.out.println("Cerrar conexion a bd");
		}catch (Exception e) {
			System.out.println("Entra en catch");
		}finally {
			System.out.println("Cerar conexion a bd");
		}
		System.out.println("fin");
	}

}
