package com.cmc.exepciones;

//Exception 
//RuntimeException las que no molestan (Unchetcjk)
//NullPinter exeption,ArrayIndexOutRoundException classCastException
public class Ejecicio4 {
	//busca en la bd del cliente con la cedula
	//que recibe como parametro si existe el cliente retorna datos ala objeto clientes 
	//caso contrario sino existe el cliente retorna null
	//si hay problema con la copneccion lanza la excepcion
	public Cliente buscar (String cedula)throws Exception{
		
		return null;
	}
}
