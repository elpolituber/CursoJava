package com.cmc.exepciones;

public class CheckedException extends Exception {
	
	public CheckedException(String mensaje){
		super(mensaje);
		
	}
}
