package com.cmc.exepciones;

import java.io.File;
import java.io.IOException;

public class Ejecicio5 {

	public static void main(String[] args) {
		File f=new File("archivo.txt");
		try {
			f.createNewFile();
			String[] a=new String[2];
			a[2]="b";
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("errro del sistema");
		}
	}

}
