package com.cmc.exepciones;

public class Cliente {

}
