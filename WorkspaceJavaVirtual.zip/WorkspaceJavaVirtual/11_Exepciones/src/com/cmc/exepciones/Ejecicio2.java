package com.cmc.exepciones;

import java.io.File;
//Checked - toxica
//Unchecked- amigos con derecho
public class Ejecicio2 {

	public static void main(String[] args) {
		File file=new File("archivo.txt");
		file.createNewFile(); 
	}

}
