package com.cmc.exepciones;

public class UnCheckedException extends RuntimeException {
	
	public UnCheckedException(String mensaje){
		super(mensaje);
	}
}
