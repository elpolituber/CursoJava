package com.cmc.exepciones;

public class TestDeposito {

	public static void main(String[] args) {
		Cuenta c=new Cuenta();
		try {
			c.depositar(-1000);
		} catch (CheckedException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		System.out.println("fin");
	}

}
