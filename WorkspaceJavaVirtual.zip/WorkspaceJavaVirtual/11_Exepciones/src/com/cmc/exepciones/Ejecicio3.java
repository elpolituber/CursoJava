package com.cmc.exepciones;

import java.io.File;
import java.io.IOException;

public class Ejecicio3 {

	public void metodo1() {
		File file = new File("archivo.txt");
		try {
			file.createNewFile();
		} catch (Exception e) {
		
		}
	}

	public void metodo2() throws IOException {
		File file = new File("archivo.txt");
		file.createNewFile();

	}
	 private void metodo3() {
		 metodo2();
	}
}
