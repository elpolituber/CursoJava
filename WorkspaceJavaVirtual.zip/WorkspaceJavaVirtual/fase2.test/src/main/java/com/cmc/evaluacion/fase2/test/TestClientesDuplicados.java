package com.cmc.evaluacion.fase2.test;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.cmc.evaluacion.fase2.commons.CheckedException;
import com.cmc.evaluacion.fase2.entidades.Cartera;
import com.cmc.evaluacion.fase2.servicios.AdminClientes;

import junit.framework.TestCase;

public class TestClientesDuplicados extends TestCase {
	private static final String ROOT="C:\\Users\\franc\\Downloads\\archivos";
	private static Logger logger = LogManager.getLogger(TestClientesDuplicados.class);

	public void testLeer() throws CheckedException{
		Cartera cartera=null;
		cartera = AdminClientes.armarCartera(ROOT+"\\Clientes2.txt");
		assertEquals(4,cartera.getClientes().size());
		assertEquals("Rolando",cartera.getClientes().get(3).getNombre());
	}
}
