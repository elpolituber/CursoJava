package com.cmc.evaluacion.fase2.test;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.cmc.evaluacion.fase2.commons.CheckedException;
import com.cmc.evaluacion.fase2.entidades.Cartera;
import com.cmc.evaluacion.fase2.servicios.AdminClientes;

import junit.framework.TestCase;

public class TestClientes extends TestCase {
	private static final String ROOT="C:\\Users\\franc\\Downloads\\archivos";
	private static Logger logger = LogManager.getLogger(TestClientes.class);

	public void testLeer() throws CheckedException{
		Cartera cartera=null;
		try {
			cartera = AdminClientes.armarCartera(ROOT+"\\Clientes1.txt");
		}finally {
			assertEquals(4,cartera.getClientes().size());
			assertEquals("Beatriz",cartera.getClientes().get(2).getNombre());	
		}
			}
}
