package com.cmc.capacitacion.excepciones;

public class ToxicaExeption extends Exception{
	public ToxicaExeption(String mensaje){
		super(mensaje);
	}
}
