package com.cmc.admin;

import com.cmc.entidad.Producto;

public class AdminProducto {
	//comparar recibir 2 tipo productos
	//comparar los precios de los productos 
	//retorna de mayor valor
	
	public Producto obtenerProductoMasCaro(Producto a, Producto b) {
		if(a.getPrecio()>b.getPrecio()){
			return a;
		}
		else  if(a.getPrecio()<b.getPrecio()){
			return b;
		}else {
			return null;
		}
	}
	
}
