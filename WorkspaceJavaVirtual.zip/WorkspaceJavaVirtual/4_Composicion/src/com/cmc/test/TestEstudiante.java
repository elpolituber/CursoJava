package com.cmc.test;

import com.cmc.entidad.Direccion;
import com.cmc.entidad.Estudiantes;

public class TestEstudiante {

	public static void main(String[] args) {
		Estudiantes est=new Estudiantes("1234521", "mario");
		
		Direccion d1= new Direccion();
		d1.setCallePrincipal("Pedro de alfadro");
		d1.setCalleSecundaria("nu�es de balboa");
		d1.setNumero("2312321");
		est.setDireccion(d1);
		est.imprimir();
		
		Estudiantes est2=new Estudiantes("1235641", "Pepe");
		est2.setDireccion(new Direccion("Syris", "abs", "534561"));
		est2.imprimir();
	}

}
