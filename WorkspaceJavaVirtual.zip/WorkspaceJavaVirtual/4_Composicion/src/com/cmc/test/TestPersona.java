package com.cmc.test;

import com.cmc.entidad.Direccion;
import com.cmc.entidad.Persona;

public class TestPersona {

	public static void main(String[] args) {
		Persona persona=new Persona();
		
		System.out.println("nombre "+persona.getNombre());
		System.out.println("EDAD "+persona.getEdad());		
		System.out.println("DIRECCION "+persona.getDireccion());
		
		Direccion dir=persona.getDireccion();
		if(dir!=null){	
		System.out.println("calle principal:"+dir.getCallePrincipal());
		}else{
			System.out.println("calle principal:"+"no existe");
			
		}
	}

}
