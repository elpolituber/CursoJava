package com.cmc.juegos;

import com.cmc.util.Dado;

public class Test {

	public static void main(String[] args) {
		Dado.lanzar();
	}

}
