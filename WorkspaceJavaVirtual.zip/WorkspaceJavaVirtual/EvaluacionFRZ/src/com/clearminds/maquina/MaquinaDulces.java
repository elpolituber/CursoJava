package com.clearminds.maquina;

import com.clearminds.componentes.Celda;
import com.clearminds.componentes.Producto;

public class MaquinaDulces {
	private Celda celda1;
	private Celda celda2;
	private Celda celda3;
	private Celda celda4;
	private double saldo;
	
	

	public void configurarMaquina(String c1,String c2,String c3,String c4){
		
		this.celda1 =new Celda(c1);
		this.celda2 =new Celda(c2);
		this.celda3 =new Celda(c3);
		this.celda4 =new Celda(c4);
		
	}
	
	public void mostrarConfiguracion(){
		System.out.println("Celda 1: "+this.celda1.getCodigo());
		System.out.println("Celda 2: "+this.celda2.getCodigo());
		System.out.println("Celda 3: "+this.celda3.getCodigo());
		System.out.println("Celda 4: "+this.celda4.getCodigo());
	}
	
	public Celda buscarCelda(String codigo){
		if(this.celda1.getCodigo()==codigo){
			return celda1;
		}
		if(this.celda2.getCodigo()==codigo){
			return celda2;
		}
		if(this.celda3.getCodigo()==codigo){
			return celda3;
		}
		if(this.celda4.getCodigo()==codigo){
			return celda4;
		}
		return null;
	}
	
	public void cargarProducto(Producto producto,String cod,int cantidad){
		Celda celdaRecuperada=this.buscarCelda(cod);
		celdaRecuperada.ingresarProducto(producto, cantidad);
	}
	
	public void mostrarProductos(){
		System.out.println("********************Celda "+this.celda1.getCodigo());
		if(this.celda1.getStock()==0){
		System.out.println("Stock: "+this.celda1.getStock()+"\nLa celda no tiene producto");	
		}else{
			System.out.println("\nStock: "+this.celda1.getStock()+"\nNombre Producto: "+this.celda1.getProducto().getNombre()+"\nPrecio Producto: "+this.celda1.getProducto().getPrecio()+"\nCodigo Producto: "+this.celda1.getProducto().getCodigo());
		}
		System.out.println("********************Celda "+this.celda2.getCodigo());
		if(this.celda2.getStock()==0){
			System.out.println("Stock: "+this.celda2.getStock()+"\nla celda no tiene producto!!!");	
			}else{
		System.out.println("Stock: "+this.celda2.getStock()+"\nNombre Producto: "+this.celda2.getProducto().getNombre()+"\nPrecio Producto: "+this.celda2.getProducto().getPrecio()+"\nCodigo Producto: "+this.celda2.getProducto().getCodigo());
			}
		
		System.out.println("\n********************Celda "+this.celda3.getCodigo());
		if(this.celda3.getStock()==0){
			System.out.println("Stock: "+this.celda3.getStock()+"\nla celda no tiene producto!!!");	
		}else{
			System.out.println("Stock: "+this.celda3.getStock()+"\nNombre Producto: "+this.celda3.getProducto().getNombre()+"\nPrecio Producto: "+this.celda3.getProducto().getPrecio()+"\nCodigo Producto: "+this.celda3.getProducto().getCodigo());
		}
		
		System.out.println("\n********************Celda "+this.celda4.getCodigo());
		if(this.celda4.getStock()==0){
			System.out.println("Stock: "+this.celda4.getStock()+"\nLa celda no tiene producto!!!!");	
		}else{
			System.out.println("Stock: "+this.celda4.getStock()+"\nNombre Producto: "+this.celda4.getProducto().getNombre()+"\nPrecio Producto: "+this.celda4.getProducto().getPrecio()+"\nCodigo Producto :"+this.celda4.getProducto().getCodigo());
		}
	}
	public Producto buscarProductoEnCelda(String codigo){
		if(this.celda1.getCodigo()==codigo){
			return celda1.getProducto();
		}
		if(this.celda2.getCodigo()==codigo){
			return celda2.getProducto();
		}
		if(this.celda3.getCodigo()==codigo){
			return celda3.getProducto();
		}
		if(this.celda4.getCodigo()==codigo){
			return celda4.getProducto();
		}
		return null;
	}
	public double consultarPrecio(String codigo){
		if(this.celda1.getCodigo()==codigo){
			return this.celda1.getProducto().getPrecio();
		}
		if(this.celda2.getCodigo()==codigo){
			return this.celda2.getProducto().getPrecio();
		}
		if(this.celda3.getCodigo()==codigo){
			return this.celda3.getProducto().getPrecio();
		}
		if(this.celda4.getCodigo()==codigo){
			return this.celda4.getProducto().getPrecio();
		}
		return 0;
	}
	
	public Celda buscarCeldaProducto(String codigo){
		if(this.celda1.getProducto() != null && this.celda1.getProducto().getCodigo()==codigo){
			return this.celda1;
		}
		if(this.celda2.getProducto() != null && this.celda2.getProducto().getCodigo()==codigo){
			return this.celda2;
		}
		if(this.celda3.getProducto() != null && this.celda3.getProducto().getCodigo()==codigo){
			return this.celda3;
		}
		if(this.celda4.getProducto() != null && this.celda4.getProducto().getCodigo()==codigo){
			return this.celda4;
		}
		return null;
	}
	
	public void incrementarProductos(String codigo,int cantidad){
		Celda celdaEncontrada=this.buscarCeldaProducto(codigo);
		celdaEncontrada.setStock(cantidad+celdaEncontrada.getStock());
	}
	
	public void vender(String codigo){
	  Celda vCelda=this.buscarCelda(codigo);	
	  vCelda.setStock(vCelda.getStock()-1);
	  this.saldo=saldo+vCelda.getProducto().getPrecio();
	  this.mostrarProductos();
	}
	public double venderConCambio(String codigo,double valorcli){
		double res=valorcli-this.buscarProductoEnCelda(codigo).getPrecio();
		return res;
	}
}
