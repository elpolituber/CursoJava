package com.cmc.evaluacion.fase2.servicios;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.cmc.evaluacion.fase2.commons.CheckedException;
import com.cmc.evaluacion.fase2.entidades.Cartera;
import com.cmc.evaluacion.fase2.entidades.Cliente;
import com.cmc.evaluacion.fase2.entidades.Prestamo;

public class AdminPrestamos {
	
	private static Logger logger = LogManager.getLogger(AdminPrestamos.class);

	public static Cartera colocarPrestamos(String ruta, Cartera car){
		File file = new File(ruta);
		BufferedReader br = null;
		FileReader fileReade = null;
		String linea = "",position="";
		int convertirNumero0;
		String[] partes;
		int convertirNumero1;
		Cliente cedula;
		try {
			fileReade = new FileReader(file);
			br = new BufferedReader(fileReade);
			while ((linea = br.readLine()) != null) {
				partes=linea.split("-");
				position=String.valueOf(partes[1].charAt(0));
				for (int i = 0; i < car.getClientes().size(); i++) {
					convertirNumero0=Integer.parseInt(partes[0]);
					convertirNumero1=Integer.parseInt(car.getClientes().get(i).getCedula());
					if(convertirNumero0==convertirNumero1){
						cedula=car.getClientes().get(i);
						car.agregandoPrestamos(new Prestamo(partes[1],cedula));	
					}
				}
			}
			
		} catch (FileNotFoundException e) {
			logger.error("Error al leer el archivo", e);
			try {
				throw new CheckedException("No existe el archivo " + ruta);
			} catch (CheckedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error("Error al leer el archivo", e);
			try {
				throw new CheckedException("Nose pudo leer archivo" + ruta);
			} catch (CheckedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} finally {
			try {
				if (br != null) {
					br.close();
				}
			} catch (IOException e) {
				logger.error("error al cerrar el FileReader", e);

			}
			try {
				if (fileReade != null) {
					fileReade.close();
				}
			} catch (IOException e) {
				logger.error("error al cerrar el BufferedReader", e);
			}
		}
		return car;
	}
	
}
