package com.cmc.evaluacion.fase2.servicios;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.cmc.evaluacion.fase2.commons.CheckedException;
import com.cmc.evaluacion.fase2.entidades.Cartera;
import com.cmc.evaluacion.fase2.entidades.Cliente;

public class AdminClientes {
	
	private static Logger logger = LogManager.getLogger(AdminClientes.class);

	public static Cartera armarCartera(String ruta) {
		File file = new File(ruta);
		BufferedReader br = null;
		FileReader fileReade = null;
		String linea = "";
		String[] partes;
		Cartera c=new Cartera();
		try {
			fileReade = new FileReader(file);
			br = new BufferedReader(fileReade);
			while ((linea = br.readLine()) != null) {
				partes=linea.split(",");
				try {
					c.agregarCliente(new Cliente(partes[0],partes[1],partes[2]));
				}
				catch ( ArrayIndexOutOfBoundsException e) {
					logger.error("Error al aramar el cliente en la linea", e);
				} 
				
			}
		} catch (FileNotFoundException e) {
			logger.error("Error al leer el archivo", e);
			try {
				throw new CheckedException("No existe el archivo " + ruta);
			} catch (CheckedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error("Error al leer el archivo", e);
			try {
				throw new CheckedException("Nose pudo leer archivo" + ruta);
			} catch (CheckedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} 
		finally {
			try {
				if (br != null) {
					br.close();
				}
			} catch (IOException e) {
				logger.error("error al cerrar el FileReader", e);

			}
			try {
				if (fileReade != null) {
					fileReade.close();
				}
			} catch (IOException e) {
				logger.error("error al cerrar el BufferedReader", e);
			}
		}
		return c;
	}
}
