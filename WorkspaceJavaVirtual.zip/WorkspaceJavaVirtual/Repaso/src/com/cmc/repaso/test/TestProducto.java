package com.cmc.repaso.test;

import com.cmc.repaso.entidades.Producto;

public class TestProducto {
	public static void main(String[] args) {
		Producto producto=new Producto("calzones", 6);
		 System.out.println("descuento: "+producto.calcularPrecioPromo(50));
		 Producto producto2=new Producto("medias", 10);
		 producto2.setPrecio(-8);
		 
		 System.out.println("descuento: "+producto2.calcularPrecioPromo(30));
		 
	}
}
