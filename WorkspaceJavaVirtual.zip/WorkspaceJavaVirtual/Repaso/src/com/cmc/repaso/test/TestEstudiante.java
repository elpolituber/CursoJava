package com.cmc.repaso.test;

import com.cmc.repaso.entidades.Estudiante;

public class TestEstudiante {

	public static void main(String[] args) {
		Estudiante estudiante=new Estudiante("Pepe");
		estudiante.calificar(8);
		
		Estudiante estudiante2=new Estudiante("Juan");
		estudiante2.calificar(5);
	}

}
