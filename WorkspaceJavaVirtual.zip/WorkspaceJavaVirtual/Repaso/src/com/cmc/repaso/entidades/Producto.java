package com.cmc.repaso.entidades;

public class Producto {
	private String nombre;
	private double precio;
	
	public Producto(String nombre, double precio) {
		//super();
		this.nombre = nombre;
		this.precio = precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio<=0?precio*-1:precio;
	}
	
	public double calcularPrecioPromo( int porsentajedescuento) {
		double valor=porsentajedescuento<=100?precio-(precio*(double)porsentajedescuento/100):precio;		
		
		return valor;
	}
	
}
