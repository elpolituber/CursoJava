package com.clearminds.maquina;

import java.util.ArrayList;

import com.clearminds.componentes.Celda;
import com.clearminds.componentes.Producto;

public class MaquinaDulces {
	private ArrayList<Celda> celdas;
	private double saldo;

	public MaquinaDulces() {
		this.celdas = new ArrayList<Celda>();
	}

	public void agregarCelda(String codigo) {
		this.celdas.add(new Celda(codigo));
	}

	public void mostrarConfiguracion() {
		for (int i = 0; i < celdas.size(); i++) {
			System.out.println("Celda:" + celdas.get(i).getCodigo());
		}
	}

	public Celda buscarCelda(String codigo) {
		Celda per = null;
		for (int i = 0; i < this.celdas.size(); i++) {
			per = this.celdas.get(i);
			if (per.getCodigo().equals(codigo)) {
				return per;
			}
		}
		return null;

	}
	public void cargarProducto(Producto producto,String codigo,int item){
		Celda celdaRecuperada=this.buscarCelda(codigo);
		celdaRecuperada.ingresarProducto(producto, item);
		this.celdas.add(celdaRecuperada);
	}
	public void mostrarProductos(){
		
		for (int i = 0; i < celdas.size(); i++) {
			if(celdas.get(i).getProducto()==null){
				System.out.println("Celda:" + celdas.get(i).getCodigo()+" Stock: "+celdas.get(i).getStock()+" Sin Producto Asignado");		
			}else{
			System.out.println("Celda:" + celdas.get(i).getCodigo()+" Stock: "+celdas.get(i).getStock()+" Producto: "+celdas.get(i).getProducto().getCodigo()+" Precio: "+celdas.get(i).getProducto().getPrecio());
			}
	
		}
	}
	public Celda buscarCeldaProducto(String codigo){
		for (int i = 0; i < celdas.size(); i++) {
			if(celdas.get(i).getProducto()!=null){
				if(celdas.get(i).getProducto().getCodigo().equals(codigo)){
					return celdas.get(i);
				}
			}
		}
		return null;
	}
	public Producto buscarProductoEnCelda(String codigo){
		for (int i = 0; i < celdas.size(); i++) {
			if(celdas.get(i).getCodigo().equals(codigo)){
				return celdas.get(i).getProducto();
			}
		}
		return null;
	}
	public double consultarPrecio(String codigo){
		for (int i = 0; i < celdas.size(); i++) {
			if(celdas.get(i).getCodigo().equals(codigo)){
				return celdas.get(i).getProducto().getPrecio();
			}
		}
		return 0;
	}
	public void incrementarProductos(String codigo,int cantidad){
		Celda celdaEncontrada=this.buscarCeldaProducto(codigo);
		celdaEncontrada.setStock(cantidad);
	}
	public void vender(String codigo){
		ArrayList<Celda> val=new ArrayList<Celda>();
		for (int i = 0; i < celdas.size(); i++) {
			if(celdas.get(i).getCodigo().equals(codigo)){
				val.add(celdas.get(i));
				celdas.get(i).setStock(val.get(0).getStock()-1);
			}
		}
		this.mostrarProductos();
	}

	public double venderConCambio(String string, int i) {
		double val=0;
		for (int j = 0; j < celdas.size(); j++) {
			if(celdas.get(j).getCodigo().equals(string)){
				val=celdas.get(j).getProducto().getPrecio();
			}
		}
		double res= i-val;
		return res;
	}
	public ArrayList<Producto> buscarMenores(double limite){
		ArrayList<Producto>pro= new ArrayList<Producto>();
		for (int i = 0; i < celdas.size(); i++) {
			if(celdas.get(i).getProducto().getPrecio()<=limite){
				pro.add(celdas.get(i).getProducto());
			}
		}
		return pro;
	}
}
