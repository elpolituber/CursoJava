package com.clearminds.test;

import java.util.ArrayList;

import com.clearminds.componentes.Producto;
import com.clearminds.maquina.MaquinaDulces;

public class TestBuscarMenores {

	public static void main(String[] args) {
		MaquinaDulces maquina=new MaquinaDulces();
		maquina.agregarCelda("A1");
		maquina.agregarCelda("A2");
		maquina.agregarCelda("A3");
		maquina.agregarCelda("B1");
		maquina.agregarCelda("B2");
		maquina.agregarCelda("B3");
		
		Producto producto0=new Producto("KE34","Papitas",0.45);
		maquina.cargarProducto(producto0, "A1", 4);
		Producto producto1=new Producto("KE35","chochos",0.85);
		maquina.cargarProducto(producto1, "A2", 4);
		Producto producto2=new Producto("KE36","choclo",0.35);
		maquina.cargarProducto(producto2, "A3", 4);
		
		Producto producto3=new Producto("D457","Doritos",0.90);
		maquina.cargarProducto(producto3, "B1", 6);
		Producto producto4=new Producto("KE38","Dipas",0.85);
		maquina.cargarProducto(producto4, "B2", 4);
		Producto producto5=new Producto("KE39","Pipas",0.35);
		maquina.cargarProducto(producto5, "B3", 4);
		ArrayList<Producto>pro=maquina.buscarMenores(0.80);
		for (int i = 0; i < pro.size(); i++) {
			System.out.println("El producto con menor valor es "+pro.get(i).getNombre());
		}
		
	}

}
