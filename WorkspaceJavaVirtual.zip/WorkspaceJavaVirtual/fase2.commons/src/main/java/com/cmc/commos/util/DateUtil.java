package com.cmc.commos.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {
	public static Date convertir(String date)throws ParseException{
		SimpleDateFormat srt=new SimpleDateFormat("yyyy/dd/MM");
		Date dateNew= new Date();
			dateNew=srt.parse(date);
		return dateNew;
	}
}
