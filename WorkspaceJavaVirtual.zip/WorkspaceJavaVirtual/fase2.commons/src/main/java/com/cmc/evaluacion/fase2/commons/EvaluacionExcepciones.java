package com.cmc.evaluacion.fase2.commons;

public class EvaluacionExcepciones extends RuntimeException {
	
	public EvaluacionExcepciones(String mensaje){
		super(mensaje);
	}
}
