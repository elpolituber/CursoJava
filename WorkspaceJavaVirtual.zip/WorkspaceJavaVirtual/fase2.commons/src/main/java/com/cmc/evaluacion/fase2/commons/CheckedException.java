package com.cmc.evaluacion.fase2.commons;

public class CheckedException extends Exception{

	public CheckedException(String mensaje){
		super(mensaje);
	}
}
