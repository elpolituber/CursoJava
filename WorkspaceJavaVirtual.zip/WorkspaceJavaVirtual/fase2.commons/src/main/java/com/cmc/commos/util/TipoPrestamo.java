package com.cmc.commos.util;

public class TipoPrestamo {
	public final static String HIPOTECARIO="H";
	public final static String QUIROGRAFARIO="Q";
	public final static String OTRO="O";

}
