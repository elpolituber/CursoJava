 package com.cmc.test;

public class TestArreglos {

	public static void main(String[] args) {
		int [] enteros=new int[3];
		enteros[0]=10;
		enteros[1]=20;
		enteros[2]=30;
		int res=enteros[1];
		System.out.println(res);
	}

}
