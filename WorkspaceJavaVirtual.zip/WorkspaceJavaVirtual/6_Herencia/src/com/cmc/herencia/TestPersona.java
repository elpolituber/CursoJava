package com.cmc.herencia;

public class TestPersona {

	public static void main(String[] args) {
		Persona p=new Persona("franco", "zabala");
		System.out.println(p);
	}
	
}
