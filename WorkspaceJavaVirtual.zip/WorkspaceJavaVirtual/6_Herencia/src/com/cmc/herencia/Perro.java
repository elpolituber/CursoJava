package com.cmc.herencia;

public class Perro extends Animal{
	public void ladrar(){
		System.out.println("ladrar");
	}
	//tiene un metodo dormir
	public void dormir(){
		super.dormir();
		System.out.println("perro dormir");
	}
}
