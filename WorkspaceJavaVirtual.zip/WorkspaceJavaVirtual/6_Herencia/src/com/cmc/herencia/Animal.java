package com.cmc.herencia;
//ereda de object
public class Animal {
	public void dormir(){
		System.out.println("animal durmiendo");
	}
	
}
