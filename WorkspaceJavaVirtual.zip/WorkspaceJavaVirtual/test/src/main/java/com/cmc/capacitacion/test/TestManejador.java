package com.cmc.capacitacion.test;

import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.cmc.capacitacion.archivos.ManejadorArchivos;
import com.cmc.capacitacion.entidades.Persona;
import com.cmc.capacitacion.excepciones.ToxicaExeption;

public class TestManejador {

	private static Logger logger=LogManager.getLogger(TestManejador.class) ;

	public static void main(String[] args) {
		ManejadorArchivos  ma=new ManejadorArchivos("C:\\Users\\franc\\Desktop\\ejemplo1.txt");
		try {
			ArrayList<Persona>per=ma.leer();
				System.out.println(per);
			
		} catch (ToxicaExeption e) {
			logger.error("Error al leer el archivo",e);
			System.out.println("Error al leer el archivo"+e.getMessage());
		}catch (Exception e) {
			logger.error("No existe el sistema de archivo",e);
			System.out.println("No existe el sistema de archivo"+e.getMessage());
	
		}
	}

}
