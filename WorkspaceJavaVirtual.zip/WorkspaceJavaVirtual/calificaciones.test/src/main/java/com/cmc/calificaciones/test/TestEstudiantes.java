package com.cmc.calificaciones.test;

import com.cmc.calificaciones.servicios.AdminEstudiante;
import com.cmc.celificacion.entidades.Estudiante;

public class TestEstudiantes {

	public static void main(String[] args) {
		AdminEstudiante ae=new AdminEstudiante();
		Estudiante e=new Estudiante("franco", "zabala");
 		ae.agregar(e);
 		System.out.println("fin");
	}

}
