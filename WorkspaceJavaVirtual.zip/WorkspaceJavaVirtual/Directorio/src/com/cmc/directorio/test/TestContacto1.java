package com.cmc.directorio.test;

import com.cmc.directorio.entidades.Contacto;
import com.cmc.directorio.entidades.Telefono;

public class TestContacto1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Telefono telef=new Telefono("movi", "09941234123", "10");
		Contacto c= new Contacto("Franco", "Zabala", telef, 10.62);
		System.out.println("Nombre "+c.getNombre()+"\nApellido "+c.getApellido()+"\nOperadora "+c.getTelefono().getOperadora()+"\nPeso "+c.getPeso()+"\nActivo "+c.getActivo());
	}

}
