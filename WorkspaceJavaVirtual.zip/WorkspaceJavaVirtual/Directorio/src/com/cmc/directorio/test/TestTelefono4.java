package com.cmc.directorio.test;

import com.cmc.directorio.admin.AdminTelefono;
import com.cmc.directorio.entidades.Telefono;

public class TestTelefono4 {

	public static void main(String[] args) {
		Telefono telf1=new Telefono("movi", "09741234122", "10");
		Telefono telf2=new Telefono("claro", "09948230120", "20");
		Telefono telf3=new Telefono("claro", "09841237123", "30");
		Telefono telf4=new Telefono("claro", "09840007123", "40");
		
		AdminTelefono at =new AdminTelefono();
		int valor=at.contarClaro(telf1, telf2, telf3,telf4);
		System.out.println(valor);
	}

}
