package com.cmc.directorio.test;

import com.cmc.directorio.admin.AdminContactos;
import com.cmc.directorio.entidades.Contacto;
import com.cmc.directorio.entidades.Telefono;

public class TestContactos2 {

	public static void main(String[] args) {
		Telefono telef=new Telefono("movi", "09941234123", "10");
		Contacto c1= new Contacto("Franco", "Zabala", telef, 12.62);
		Telefono telef1=new Telefono("claro", "09900004123", "10");
		Contacto c2= new Contacto("Rodrigo", "Nogales", telef1, 11.62);
		AdminContactos adminCont=new AdminContactos();
		Contacto res= adminCont.buscarMasPesado(c1, c2);
		System.out.println("El contacto con mas peso es"+"\nNombre "+res.getNombre()+"\nApellido "+res.getApellido()+"\nOperadora "+res.getTelefono().getOperadora()+"\nPeso "+res.getPeso()+"\nActivo "+res.getActivo());
		boolean res1= adminCont.compararOperadoras(c1, c2);
		System.out.println("Comp�rada las operadoras es "+res1);
	}

}
