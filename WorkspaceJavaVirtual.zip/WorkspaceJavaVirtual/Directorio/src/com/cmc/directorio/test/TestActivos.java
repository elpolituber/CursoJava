package com.cmc.directorio.test;

import com.cmc.directorio.admin.AdminContactos;
import com.cmc.directorio.admin.AdminTelefono;
import com.cmc.directorio.entidades.Contacto;
import com.cmc.directorio.entidades.Telefono;

public class TestActivos {

	public static void main(String[] args) {
		Telefono telef=new Telefono("movi", "09941234123", "10");
		Contacto c1= new Contacto("Franco", "Zabala", telef, 10.62);
		AdminContactos adminCont=new AdminContactos();
		adminCont.activarUsuario(c1);
		System.out.println(c1.getTelefono().getTieneWhatsapp());

		Telefono telef1=new Telefono("movi", "09941234123", "10");
		AdminTelefono at=new AdminTelefono();
		at.activarMesajeria(telef1);
		Contacto c2= new Contacto("Franco", "Zabala", telef1, 10.62);
		adminCont.activarUsuario(c2);
		System.out.println(c2.getTelefono().getTieneWhatsapp());
		
	}

}
