package com.cmc.directorio.entidades;

public class Telefono {
	private String operadora;
	private String numero;
	private String codigo;
	private boolean tieneWhatsapp;
	
	public Telefono(String operadora, String numero, String codigo) {
		super();
		this.operadora = operadora;
		this.numero = numero;
		this.codigo = codigo;
	}

	public boolean getTieneWhatsapp() {
		return tieneWhatsapp;
	}

	public void setTieneWhatsapp(boolean tieneWhatsapp) {
		this.tieneWhatsapp = tieneWhatsapp;
	}

	public String getOperadora() {
		return operadora;
	}

	public String getNumero() {
		return numero;
	}

	public String getCodigo() {
		return codigo;
	}
	
	
}
