package com.cmc.directorio.admin;

import com.cmc.directorio.entidades.Telefono;

public class AdminTelefono {
	
	public  void activarMesajeria(Telefono tel){
		if(tel.getOperadora()=="movi"){
			tel.setTieneWhatsapp(true);	
		}
	}
	public int contarMovi(Telefono tel1,Telefono tel2,Telefono tel3){
		int num=0;
		if(tel1.getOperadora()=="movi"){
			num=num+1;
		}
		if(tel2.getOperadora()=="movi"){
			num=num+1;
		}
		if(tel3.getOperadora()=="movi"){
			num=num+1;
		}
		return num;
	}
	
	public int contarClaro(Telefono tel1,Telefono tel2,Telefono tel3,Telefono tel4){
		int num=0;
		if(tel1.getOperadora()=="claro"){
			num=num+1;
		}
		if(tel2.getOperadora()=="claro"){
			num=num+1;
		}
		if(tel3.getOperadora()=="claro"){
			num=num+1;
		}
		if(tel4.getOperadora()=="claro"){
			num=num+1;
		}
		return num;
	}
}
